# nxp-pn5xx
NXP's NFC Open Source Kernel mode driver
